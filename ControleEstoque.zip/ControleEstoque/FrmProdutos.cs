﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ControleEstoque1
{
    public partial class FrmProdutos : Form
    {
        public FrmProdutos()
        {
            InitializeComponent();
            BloqueiaCampos();
            CarregarGridProduto();
        }



        private void CarregarGridProduto()
        {
            Model get = new Model();
            List<DtoProdutos2> lista = get.ListProdutos();
            this.dataGridViewProdutos.DataSource = lista;
            this.dataGridViewProdutos.Refresh();
        }

        private void bntNovoProduto_Click(object sender, EventArgs e)
        {
            textBoxNomeProduto.Text = string.Empty;
            textBoxCodigoProduto.Text = string.Empty;
            textBoxPrecoProduto.Text = string.Empty;
            LilberaCampos();
            textBoxNomeProduto.Focus();
        }

        private void btnSalvarProduto_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    Model set = new Model();
                    DtoProdutos u = new DtoProdutos();
                    u.nome = textBoxNomeProduto.Text;
                    u.preco = textBoxPrecoProduto.Text;
                    if (textBoxCodigoProduto.Text != string.Empty)
                    {
                        u.codigo = int.Parse(textBoxCodigoProduto.Text);
                        set.EditProduto(u);
                    }
                    else
                    {
                        set.SetProduto(u);
                    }

                    BloqueiaCampos();
                    CarregarGridProduto();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void LilberaCampos()
        {
            textBoxNomeProduto.Enabled = true;
            textBoxCodigoProduto.Enabled = true;
            textBoxPrecoProduto.Enabled = true;
        }
        private void BloqueiaCampos()
        {
            textBoxNomeProduto.Enabled = false;
            textBoxCodigoProduto.Enabled = false;
            textBoxPrecoProduto.Enabled = false;
        }


        private void btnEditarProduto_Click(object sender, EventArgs e)
        {
            LilberaCampos();
            textBoxNomeProduto.Focus();
        }

        private void btnExcluirProduto_Click(object sender, EventArgs e)
        {
            if (textBoxCodigoProduto.Text != string.Empty)
            {
                Model del = new Model();
                del.DeletarUsuario(int.Parse(textBoxCodigoProduto.Text));
                BloqueiaCampos();
                CarregarGridProduto();
            }
        }

        private void dataGridViewProdutos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int codigo = (Int32)dataGridViewProdutos.CurrentRow.Cells[0].Value;

            Model get = new Model();
            DtoProdutos2 d = get.GetCodigo(codigo);
            textBoxCodigoProduto.Text = d.codigo.ToString();
            textBoxNomeProduto.Text = d.nome;
            LilberaCampos();
            textBoxNomeProduto.Focus();
        }
    }
}
