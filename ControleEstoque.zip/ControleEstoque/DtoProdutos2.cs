﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ControleEstoque1
{
    
      
        public class DtoProdutos2
        {
            public int codigo { get; set; }
            public string nome { get; set; }
    }
}
