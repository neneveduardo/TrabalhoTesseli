﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ControleEstoque1
{

        [Table("produto", Schema = "public")]
        public class DtoProdutos
        {
            [Key]
            public int codigo { get; set; }
            public string nome { get; set; }
            public string preco { get; set; }
        }
}
