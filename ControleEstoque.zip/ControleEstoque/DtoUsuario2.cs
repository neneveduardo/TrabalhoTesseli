﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ControleEstoque1
{
    public class DtoUsuario2
    {
        public int id { get; set; }
        public string nome { get; set; }

    }
}
