﻿
namespace ControleEstoque1
{
    partial class FrmProdutos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExcluirProduto = new System.Windows.Forms.Button();
            this.btnEditarProduto = new System.Windows.Forms.Button();
            this.btnSalvarProduto = new System.Windows.Forms.Button();
            this.bntNovoProduto = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.testeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teste3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teste4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxNomeProduto = new System.Windows.Forms.TextBox();
            this.labelNomeProduto = new System.Windows.Forms.Label();
            this.textBoxCodigoProduto = new System.Windows.Forms.TextBox();
            this.labelCodigoProduto = new System.Windows.Forms.Label();
            this.textBoxPrecoProduto = new System.Windows.Forms.TextBox();
            this.labelPrecoProduto = new System.Windows.Forms.Label();
            this.dataGridViewProdutos = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProdutos)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.btnExcluirProduto);
            this.panel1.Controls.Add(this.btnEditarProduto);
            this.panel1.Controls.Add(this.btnSalvarProduto);
            this.panel1.Controls.Add(this.bntNovoProduto);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 30);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1067, 105);
            this.panel1.TabIndex = 3;
            // 
            // btnExcluirProduto
            // 
            this.btnExcluirProduto.Cursor = System.Windows.Forms.Cursors.No;
            this.btnExcluirProduto.FlatAppearance.BorderSize = 0;
            this.btnExcluirProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluirProduto.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExcluirProduto.Image = global::ControleEstoque1.Properties.Resources.icons8_lixeira_cheia_32;
            this.btnExcluirProduto.Location = new System.Drawing.Point(312, 16);
            this.btnExcluirProduto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnExcluirProduto.Name = "btnExcluirProduto";
            this.btnExcluirProduto.Size = new System.Drawing.Size(91, 71);
            this.btnExcluirProduto.TabIndex = 3;
            this.btnExcluirProduto.UseVisualStyleBackColor = true;
            this.btnExcluirProduto.Click += new System.EventHandler(this.btnExcluirProduto_Click);
            // 
            // btnEditarProduto
            // 
            this.btnEditarProduto.Cursor = System.Windows.Forms.Cursors.No;
            this.btnEditarProduto.FlatAppearance.BorderSize = 0;
            this.btnEditarProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditarProduto.Image = global::ControleEstoque1.Properties.Resources.icons8_lápis_32;
            this.btnEditarProduto.Location = new System.Drawing.Point(213, 16);
            this.btnEditarProduto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEditarProduto.Name = "btnEditarProduto";
            this.btnEditarProduto.Size = new System.Drawing.Size(91, 71);
            this.btnEditarProduto.TabIndex = 2;
            this.btnEditarProduto.UseVisualStyleBackColor = true;
            this.btnEditarProduto.Click += new System.EventHandler(this.btnEditarProduto_Click);
            // 
            // btnSalvarProduto
            // 
            this.btnSalvarProduto.Cursor = System.Windows.Forms.Cursors.No;
            this.btnSalvarProduto.FlatAppearance.BorderSize = 0;
            this.btnSalvarProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarProduto.Image = global::ControleEstoque1.Properties.Resources.icons8_salvar_32;
            this.btnSalvarProduto.Location = new System.Drawing.Point(115, 16);
            this.btnSalvarProduto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSalvarProduto.Name = "btnSalvarProduto";
            this.btnSalvarProduto.Size = new System.Drawing.Size(91, 71);
            this.btnSalvarProduto.TabIndex = 1;
            this.btnSalvarProduto.UseVisualStyleBackColor = true;
            this.btnSalvarProduto.Click += new System.EventHandler(this.btnSalvarProduto_Click);
            // 
            // bntNovoProduto
            // 
            this.bntNovoProduto.Cursor = System.Windows.Forms.Cursors.No;
            this.bntNovoProduto.FlatAppearance.BorderSize = 0;
            this.bntNovoProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bntNovoProduto.Image = global::ControleEstoque1.Properties.Resources.icons8_document_32;
            this.bntNovoProduto.Location = new System.Drawing.Point(16, 16);
            this.bntNovoProduto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bntNovoProduto.Name = "bntNovoProduto";
            this.bntNovoProduto.Size = new System.Drawing.Size(91, 71);
            this.bntNovoProduto.TabIndex = 0;
            this.bntNovoProduto.UseVisualStyleBackColor = true;
            this.bntNovoProduto.Click += new System.EventHandler(this.bntNovoProduto_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.testeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1067, 30);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // testeToolStripMenuItem
            // 
            this.testeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.teste3ToolStripMenuItem,
            this.teste4ToolStripMenuItem});
            this.testeToolStripMenuItem.Name = "testeToolStripMenuItem";
            this.testeToolStripMenuItem.Size = new System.Drawing.Size(88, 26);
            this.testeToolStripMenuItem.Text = "Cadastros";
            // 
            // teste3ToolStripMenuItem
            // 
            this.teste3ToolStripMenuItem.Name = "teste3ToolStripMenuItem";
            this.teste3ToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.teste3ToolStripMenuItem.Text = "Usuário";
            // 
            // teste4ToolStripMenuItem
            // 
            this.teste4ToolStripMenuItem.Name = "teste4ToolStripMenuItem";
            this.teste4ToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.teste4ToolStripMenuItem.Text = "Produto";
            // 
            // textBoxNomeProduto
            // 
            this.textBoxNomeProduto.Location = new System.Drawing.Point(115, 190);
            this.textBoxNomeProduto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxNomeProduto.Name = "textBoxNomeProduto";
            this.textBoxNomeProduto.Size = new System.Drawing.Size(305, 22);
            this.textBoxNomeProduto.TabIndex = 4;
            // 
            // labelNomeProduto
            // 
            this.labelNomeProduto.AutoSize = true;
            this.labelNomeProduto.Location = new System.Drawing.Point(7, 193);
            this.labelNomeProduto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNomeProduto.Name = "labelNomeProduto";
            this.labelNomeProduto.Size = new System.Drawing.Size(99, 17);
            this.labelNomeProduto.TabIndex = 5;
            this.labelNomeProduto.Text = "Nome Produto";
            // 
            // textBoxCodigoProduto
            // 
            this.textBoxCodigoProduto.Location = new System.Drawing.Point(115, 251);
            this.textBoxCodigoProduto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxCodigoProduto.Name = "textBoxCodigoProduto";
            this.textBoxCodigoProduto.Size = new System.Drawing.Size(305, 22);
            this.textBoxCodigoProduto.TabIndex = 6;
            // 
            // labelCodigoProduto
            // 
            this.labelCodigoProduto.AutoSize = true;
            this.labelCodigoProduto.Location = new System.Drawing.Point(28, 255);
            this.labelCodigoProduto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCodigoProduto.Name = "labelCodigoProduto";
            this.labelCodigoProduto.Size = new System.Drawing.Size(52, 17);
            this.labelCodigoProduto.TabIndex = 7;
            this.labelCodigoProduto.Text = "Codigo";
            // 
            // textBoxPrecoProduto
            // 
            this.textBoxPrecoProduto.Location = new System.Drawing.Point(115, 315);
            this.textBoxPrecoProduto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxPrecoProduto.Name = "textBoxPrecoProduto";
            this.textBoxPrecoProduto.Size = new System.Drawing.Size(188, 22);
            this.textBoxPrecoProduto.TabIndex = 8;
            // 
            // labelPrecoProduto
            // 
            this.labelPrecoProduto.AutoSize = true;
            this.labelPrecoProduto.Location = new System.Drawing.Point(28, 319);
            this.labelPrecoProduto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPrecoProduto.Name = "labelPrecoProduto";
            this.labelPrecoProduto.Size = new System.Drawing.Size(45, 17);
            this.labelPrecoProduto.TabIndex = 10;
            this.labelPrecoProduto.Text = "Preço";
            // 
            // dataGridViewProdutos
            // 
            this.dataGridViewProdutos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProdutos.Location = new System.Drawing.Point(115, 354);
            this.dataGridViewProdutos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridViewProdutos.Name = "dataGridViewProdutos";
            this.dataGridViewProdutos.RowHeadersWidth = 51;
            this.dataGridViewProdutos.Size = new System.Drawing.Size(815, 185);
            this.dataGridViewProdutos.TabIndex = 11;
            this.dataGridViewProdutos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProdutos_CellContentClick);
            // 
            // FrmProdutos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.dataGridViewProdutos);
            this.Controls.Add(this.labelPrecoProduto);
            this.Controls.Add(this.textBoxPrecoProduto);
            this.Controls.Add(this.labelCodigoProduto);
            this.Controls.Add(this.textBoxCodigoProduto);
            this.Controls.Add(this.labelNomeProduto);
            this.Controls.Add(this.textBoxNomeProduto);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmProdutos";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProdutos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button btnExcluirProduto;
        public System.Windows.Forms.Button btnEditarProduto;
        public System.Windows.Forms.Button btnSalvarProduto;
        public System.Windows.Forms.Button bntNovoProduto;
        private System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem testeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teste3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teste4ToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxNomeProduto;
        private System.Windows.Forms.Label labelNomeProduto;
        private System.Windows.Forms.TextBox textBoxCodigoProduto;
        private System.Windows.Forms.Label labelCodigoProduto;
        private System.Windows.Forms.TextBox textBoxPrecoProduto;
        private System.Windows.Forms.Label labelPrecoProduto;
        private System.Windows.Forms.DataGridView dataGridViewProdutos;
    }
}